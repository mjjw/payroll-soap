package com.example.payroll.endpoint;

import com.example.payroll.service.PayrollService;
import com.example.payroll.ws.GetEmployeeRequest;
import com.example.payroll.ws.GetEmployeeResponse;
import com.example.payroll.ws.GetPayslipsRequest;
import com.example.payroll.ws.GetPayslipsResponse;
import com.example.payroll.ws.ListEmployeesRequest;
import com.example.payroll.ws.ListEmployeesResponse;
import com.example.payroll.ws.RunPayrollRequest;
import com.example.payroll.ws.RunPayrollResponse;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDate;

@Endpoint
public class PayrollEndpoint {

    private static final String NAMESPACE_URI = "http://example.com/payroll";

    private final PayrollService payrollService;

    public PayrollEndpoint(PayrollService payrollService) {
        this.payrollService = payrollService;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getEmployeeRequest")
    @ResponsePayload
    public GetEmployeeResponse getEmployee(@RequestPayload GetEmployeeRequest request) {
        GetEmployeeResponse response = new GetEmployeeResponse();
        response.setEmployee(toWs(payrollService.getEmployee(request.getEmployeeId())));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "listEmployeesRequest")
    @ResponsePayload
    public ListEmployeesResponse listEmployees(@RequestPayload ListEmployeesRequest request) {
        ListEmployeesResponse response = new ListEmployeesResponse();
        payrollService.listEmployees().forEach(employee -> response.getEmployee().add(toWs(employee)));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getPayslipsRequest")
    @ResponsePayload
    public GetPayslipsResponse getPayslips(@RequestPayload GetPayslipsRequest request) {
        GetPayslipsResponse response = new GetPayslipsResponse();
        payrollService.getPayslips(request.getEmployeeId()).forEach(payslip -> response.getPayslip().add(toWs(payslip)));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "runPayrollRequest")
    @ResponsePayload
    public RunPayrollResponse runPayroll(@RequestPayload RunPayrollRequest request) {
        var payslip = payrollService.runPayroll(
                request.getEmployeeId(),
                toLocalDate(request.getPeriodStart()),
                toLocalDate(request.getPeriodEnd()));

        RunPayrollResponse response = new RunPayrollResponse();
        response.setPayslip(toWs(payslip));
        return response;
    }

    // ---- mapping helpers: domain objects <-> generated JAXB (ws) types ----

    private com.example.payroll.ws.Employee toWs(com.example.payroll.domain.Employee employee) {
        com.example.payroll.ws.Employee ws = new com.example.payroll.ws.Employee();
        ws.setEmployeeId(employee.getEmployeeId());
        ws.setFirstName(employee.getFirstName());
        ws.setLastName(employee.getLastName());
        ws.setEmail(employee.getEmail());
        ws.setDepartment(employee.getDepartment());
        ws.setJobTitle(employee.getJobTitle());
        ws.setAnnualSalary(employee.getAnnualSalary());
        ws.setHireDate(toXmlDate(employee.getHireDate()));
        return ws;
    }

    private com.example.payroll.ws.Payslip toWs(com.example.payroll.domain.Payslip payslip) {
        com.example.payroll.ws.Payslip ws = new com.example.payroll.ws.Payslip();
        ws.setPayslipId(payslip.getPayslipId());
        ws.setEmployeeId(payslip.getEmployeeId());
        ws.setPeriodStart(toXmlDate(payslip.getPeriodStart()));
        ws.setPeriodEnd(toXmlDate(payslip.getPeriodEnd()));
        ws.setGrossPay(payslip.getGrossPay());
        ws.setTaxDeduction(payslip.getTaxDeduction());
        ws.setNetPay(payslip.getNetPay());
        ws.setIssueDate(toXmlDate(payslip.getIssueDate()));
        return ws;
    }

    private static LocalDate toLocalDate(XMLGregorianCalendar calendar) {
        return LocalDate.of(calendar.getYear(), calendar.getMonth(), calendar.getDay());
    }

    private static XMLGregorianCalendar toXmlDate(LocalDate date) {
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendarDate(
                    date.getYear(), date.getMonthValue(), date.getDayOfMonth(), DatatypeConstants.FIELD_UNDEFINED);
        } catch (DatatypeConfigurationException e) {
            throw new IllegalStateException("Unable to create XML date", e);
        }
    }
}
