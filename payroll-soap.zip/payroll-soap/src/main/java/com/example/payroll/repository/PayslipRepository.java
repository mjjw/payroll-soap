package com.example.payroll.repository;

import com.example.payroll.domain.Payslip;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PayslipRepository extends JpaRepository<Payslip, String> {

    List<Payslip> findByEmployeeIdOrderByPeriodStartDesc(String employeeId);
}
