package com.example.payroll.service;

import com.example.payroll.domain.Employee;
import com.example.payroll.domain.Payslip;
import com.example.payroll.repository.EmployeeRepository;
import com.example.payroll.repository.PayslipRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class PayrollService {

    // Simplified mock payroll math: semi-monthly pay periods, flat tax rate.
    private static final BigDecimal PAY_PERIODS_PER_YEAR = BigDecimal.valueOf(24);
    private static final BigDecimal FLAT_TAX_RATE = new BigDecimal("0.22");

    private final EmployeeRepository employeeRepository;
    private final PayslipRepository payslipRepository;

    public PayrollService(EmployeeRepository employeeRepository, PayslipRepository payslipRepository) {
        this.employeeRepository = employeeRepository;
        this.payslipRepository = payslipRepository;
    }

    public Employee getEmployee(String employeeId) {
        return employeeRepository.findById(employeeId)
                .orElseThrow(() -> new EmployeeNotFoundException(employeeId));
    }

    public List<Employee> listEmployees() {
        return employeeRepository.findAll();
    }

    public List<Payslip> getPayslips(String employeeId) {
        // validates the employee exists, raising a SOAP fault otherwise
        getEmployee(employeeId);
        return payslipRepository.findByEmployeeIdOrderByPeriodStartDesc(employeeId);
    }

    @Transactional
    public Payslip runPayroll(String employeeId, LocalDate periodStart, LocalDate periodEnd) {
        Employee employee = getEmployee(employeeId);

        BigDecimal gross = employee.getAnnualSalary()
                .divide(PAY_PERIODS_PER_YEAR, 2, RoundingMode.HALF_UP);
        BigDecimal tax = gross.multiply(FLAT_TAX_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal net = gross.subtract(tax);

        Payslip payslip = new Payslip();
        payslip.setPayslipId("PS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        payslip.setEmployeeId(employeeId);
        payslip.setPeriodStart(periodStart);
        payslip.setPeriodEnd(periodEnd);
        payslip.setGrossPay(gross);
        payslip.setTaxDeduction(tax);
        payslip.setNetPay(net);
        payslip.setIssueDate(LocalDate.now());

        return payslipRepository.save(payslip);
    }
}
