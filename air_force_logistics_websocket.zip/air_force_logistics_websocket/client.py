import asyncio
import json
import os
import websockets

WS_URL = os.getenv("WS_URL", "ws://localhost:8000/ws/logistics")
TOKEN = os.getenv("LOGISTICS_WS_TOKEN", "")

async def main():
    url = f"{WS_URL}?token={TOKEN}" if TOKEN else WS_URL
    async with websockets.connect(url) as ws:
        welcome = json.loads(await ws.recv())
        print("Connected:", json.dumps(welcome, indent=2))

        await ws.send(json.dumps({
            "action": "subscribe",
            "topics": ["readiness", "inventory", "maintenance", "transport"]
        }))

        async for raw in ws:
            message = json.loads(raw)
            print(json.dumps(message, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
