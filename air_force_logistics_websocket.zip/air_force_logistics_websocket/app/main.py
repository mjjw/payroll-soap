import asyncio
import json
import os
import random
import time
import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Query
from fastapi.responses import JSONResponse

app = FastAPI(
    title="Air Force Logistics WebSocket Demo",
    description="Synthetic, unclassified logistics events for a containerized WebSocket service.",
    version="1.0.0",
)

# DEMO ONLY: use a proper identity provider and short-lived tokens in production.
WS_TOKEN = os.getenv("LOGISTICS_WS_TOKEN", "")
EVENT_INTERVAL_SECONDS = float(os.getenv("EVENT_INTERVAL_SECONDS", "3"))
MAX_CLIENTS = int(os.getenv("MAX_CLIENTS", "100"))

TOPICS = {"readiness", "inventory", "maintenance", "transport"}
BASELINE = {
    "aircraft": [
        {"asset_id": "DEMO-AC-001", "unit": "DEMO-WING-01", "mission_capable": True, "supply_status": "GREEN"},
        {"asset_id": "DEMO-AC-002", "unit": "DEMO-WING-01", "mission_capable": False, "supply_status": "AMBER"},
        {"asset_id": "DEMO-AC-003", "unit": "DEMO-WING-02", "mission_capable": True, "supply_status": "GREEN"},
    ],
    "parts": [
        {"part_number": "DEMO-PN-1001", "description": "Hydraulic pump assembly", "on_hand": 7, "reorder_point": 4},
        {"part_number": "DEMO-PN-2002", "description": "Avionics cooling fan", "on_hand": 3, "reorder_point": 5},
        {"part_number": "DEMO-PN-3003", "description": "Landing gear sensor", "on_hand": 12, "reorder_point": 6},
    ],
}

clients: set[WebSocket] = set()
client_topics: dict[WebSocket, set[str]] = {}
client_lock = asyncio.Lock()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def event(topic: str, event_type: str, data: dict[str, Any]) -> dict[str, Any]:
    return {
        "event_id": str(uuid.uuid4()),
        "event_type": event_type,
        "topic": topic,
        "timestamp": now_iso(),
        "classification": "UNCLASSIFIED//SYNTHETIC DEMO DATA",
        "source": "logistics-demo-generator",
        "data": data,
    }


def generate_event() -> dict[str, Any]:
    """Generate synthetic data only; no operational or real-world records are used."""
    topic = random.choice(sorted(TOPICS))
    if topic == "readiness":
        aircraft = random.choice(BASELINE["aircraft"])
        return event(topic, "asset.readiness.updated", {
            "asset_id": aircraft["asset_id"],
            "unit": aircraft["unit"],
            "mission_capable": random.choice([True, True, True, False]),
            "supply_status": random.choice(["GREEN", "GREEN", "AMBER", "RED"]),
            "readiness_percent": random.randint(65, 100),
        })
    if topic == "inventory":
        part = random.choice(BASELINE["parts"])
        on_hand = max(0, part["on_hand"] + random.choice([-2, -1, 0, 1, 2]))
        return event(topic, "inventory.stock.updated", {
            "part_number": part["part_number"],
            "description": part["description"],
            "on_hand": on_hand,
            "reorder_point": part["reorder_point"],
            "reorder_recommended": on_hand <= part["reorder_point"],
            "location": random.choice(["DEMO-DEPOT-A", "DEMO-BASE-B", "DEMO-WAREHOUSE-C"]),
        })
    if topic == "maintenance":
        return event(topic, "maintenance.work_order.updated", {
            "work_order_id": f"DEMO-WO-{random.randint(10000, 99999)}",
            "asset_id": random.choice([a["asset_id"] for a in BASELINE["aircraft"]]),
            "status": random.choice(["OPEN", "IN_PROGRESS", "WAITING_FOR_PART", "COMPLETE"]),
            "priority": random.choice(["ROUTINE", "PRIORITY", "URGENT"]),
            "estimated_completion_hours": random.randint(1, 72),
        })
    return event(topic, "transport.shipment.updated", {
        "shipment_id": f"DEMO-SHP-{random.randint(10000, 99999)}",
        "part_number": random.choice([p["part_number"] for p in BASELINE["parts"]]),
        "status": random.choice(["PICKED_UP", "IN_TRANSIT", "AT_HUB", "DELIVERED", "DELAYED"]),
        "origin": random.choice(["DEMO-DEPOT-A", "DEMO-SUPPLIER-X"]),
        "destination": random.choice(["DEMO-BASE-B", "DEMO-DEPOT-C"]),
        "eta_hours": random.randint(1, 48),
    })


async def send_json_safely(ws: WebSocket, payload: dict[str, Any]) -> bool:
    try:
        await ws.send_json(payload)
        return True
    except Exception:
        return False


async def broadcast(payload: dict[str, Any]) -> None:
    async with client_lock:
        recipients = [
            ws for ws in clients
            if payload.get("topic") in client_topics.get(ws, TOPICS)
        ]
    if recipients:
        results = await asyncio.gather(
            *(send_json_safely(ws, payload) for ws in recipients),
            return_exceptions=True,
        )
        dead = [ws for ws, ok in zip(recipients, results) if ok is not True]
        if dead:
            async with client_lock:
                for ws in dead:
                    clients.discard(ws)
                    client_topics.pop(ws, None)


@app.on_event("startup")
async def start_event_publisher() -> None:
    async def publisher() -> None:
        while True:
            await broadcast(generate_event())
            await asyncio.sleep(EVENT_INTERVAL_SECONDS)
    asyncio.create_task(publisher())


@app.get("/")
async def root() -> dict[str, Any]:
    return {
        "service": "Air Force Logistics WebSocket Demo",
        "websocket": "/ws/logistics",
        "topics": sorted(TOPICS),
        "sample_client": "python client.py",
        "data": "Synthetic demonstration data only",
    }


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "time": now_iso()}


@app.get("/api/logistics/snapshot")
async def snapshot() -> dict[str, Any]:
    return {
        "timestamp": now_iso(),
        "classification": "UNCLASSIFIED//SYNTHETIC DEMO DATA",
        "aircraft": BASELINE["aircraft"],
        "parts_inventory": BASELINE["parts"],
        "topics": sorted(TOPICS),
    }


@app.websocket("/ws/logistics")
async def logistics_websocket(
    websocket: WebSocket,
    token: str | None = Query(default=None),
) -> None:
    # If LOGISTICS_WS_TOKEN is configured, clients must supply ?token=...
    if WS_TOKEN and token != WS_TOKEN:
        await websocket.close(code=1008, reason="Unauthorized")
        return

    await websocket.accept()
    async with client_lock:
        if len(clients) >= MAX_CLIENTS:
            await websocket.close(code=1013, reason="Maximum client count reached")
            return
        clients.add(websocket)
        client_topics[websocket] = set(TOPICS)

    await websocket.send_json({
        "message_type": "welcome",
        "service": "air-force-logistics-demo",
        "subscribed_topics": sorted(TOPICS),
        "available_topics": sorted(TOPICS),
        "instructions": {
            "subscribe": {"action": "subscribe", "topics": ["inventory", "maintenance"]},
            "ping": {"action": "ping"},
        },
        "timestamp": now_iso(),
    })

    try:
        while True:
            message = await websocket.receive_text()
            try:
                command = json.loads(message)
            except json.JSONDecodeError:
                await websocket.send_json({"message_type": "error", "error": "Send valid JSON."})
                continue

            action = command.get("action")
            if action == "ping":
                await websocket.send_json({"message_type": "pong", "timestamp": now_iso()})
            elif action == "subscribe":
                requested = command.get("topics", [])
                if not isinstance(requested, list) or not all(isinstance(x, str) for x in requested):
                    await websocket.send_json({"message_type": "error", "error": "'topics' must be a list of strings."})
                    continue
                invalid = sorted(set(requested) - TOPICS)
                if invalid:
                    await websocket.send_json({
                        "message_type": "error",
                        "error": "Unknown topic(s).",
                        "invalid_topics": invalid,
                        "available_topics": sorted(TOPICS),
                    })
                    continue
                async with client_lock:
                    client_topics[websocket] = set(requested)
                await websocket.send_json({
                    "message_type": "subscription_updated",
                    "subscribed_topics": sorted(requested),
                    "timestamp": now_iso(),
                })
            elif action == "unsubscribe_all":
                async with client_lock:
                    client_topics[websocket] = set()
                await websocket.send_json({"message_type": "subscription_updated", "subscribed_topics": []})
            else:
                await websocket.send_json({
                    "message_type": "error",
                    "error": "Unknown action. Supported actions: subscribe, unsubscribe_all, ping.",
                })
    except WebSocketDisconnect:
        pass
    finally:
        async with client_lock:
            clients.discard(websocket)
            client_topics.pop(websocket, None)


@app.exception_handler(HTTPException)
async def http_exception_handler(_, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
