# Air Force Logistics WebSocket Demo

A small, containerized Python service that streams **synthetic, unclassified demonstration events** for an Air Force logistics use case. It is not connected to real Air Force systems and must not be populated with operational, CUI, classified, export-controlled, or personally identifiable information.

## What it demonstrates

- Persistent WebSocket connection for near-real-time event delivery.
- Four event topics:
  - `readiness` — synthetic aircraft readiness changes.
  - `inventory` — synthetic part stock levels and reorder recommendations.
  - `maintenance` — work-order status changes.
  - `transport` — shipment status and ETA updates.
- Subscription filtering: a client chooses which topics it wants.
- REST endpoints for health and a baseline logistics snapshot.
- Docker Compose deployment, non-root runtime user, read-only container filesystem, dropped Linux capabilities, and optional shared-token gate.

## Architecture

```text
Synthetic logistics event generator
             |
             v
      FastAPI / Uvicorn
       /            \
 REST snapshot     WebSocket /ws/logistics
 /health            | subscribe to topics
                    v
             Logistics dashboard/client
```

This is a demonstration pattern. For an operational architecture, place the service behind an approved TLS reverse proxy or API gateway, integrate with the program's approved ICAM/OIDC provider, validate authorization for each topic, add durable messaging (for example, a broker) if replay and delivery guarantees are needed, and apply the relevant RMF, logging, monitoring, boundary, and data-handling controls.

## Run with Docker Compose

Prerequisite: Docker Engine/Desktop with the Compose plugin.

```bash
docker compose up --build -d
docker compose ps
```

Check service health and the REST snapshot:

```bash
curl http://localhost:8000/health
curl http://localhost:8000/api/logistics/snapshot
```

Open the interactive API page at `http://localhost:8000/docs`.

Stream events from a local Python environment:

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# Linux/macOS:
source .venv/bin/activate
pip install -r requirements.txt
python client.py
```

The client prints incoming JSON events. Stop the service with:

```bash
docker compose down
```

## Optional shared-token check

For a local demonstration, you can set a token. This is a simple gate, **not a substitute for enterprise identity, role-based access control, or mutual TLS**.

Linux/macOS:
```bash
export LOGISTICS_WS_TOKEN='replace-with-a-long-random-secret'
docker compose up --build -d
python client.py
```

PowerShell:
```powershell
$env:LOGISTICS_WS_TOKEN = "replace-with-a-long-random-secret"
docker compose up --build -d
python client.py
```

The client automatically appends `?token=...` when the environment variable is set. Do not place real secrets in source control or shell history. For anything beyond an isolated local demo, use an approved secrets mechanism and identity integration. Avoid query-string tokens in production because URLs can be logged.

## WebSocket protocol

Connect to `ws://localhost:8000/ws/logistics` (local demo only; use `wss://` through an approved TLS endpoint outside localhost).

On connect, the service sends a `welcome` message. By default, the client is subscribed to all topics.

Subscribe to selected topics:
```json
{"action":"subscribe","topics":["inventory","maintenance"]}
```

Unsubscribe from all topics:
```json
{"action":"unsubscribe_all"}
```

Heartbeat:
```json
{"action":"ping"}
```

The server responds to ping with a `pong` message. Invalid JSON, unknown actions, or unknown topics return an `error` message.

### Example event

```json
{
  "event_id": "generated-uuid",
  "event_type": "inventory.stock.updated",
  "topic": "inventory",
  "timestamp": "2026-10-22T15:00:00+00:00",
  "classification": "UNCLASSIFIED//SYNTHETIC DEMO DATA",
  "source": "logistics-demo-generator",
  "data": {
    "part_number": "DEMO-PN-2002",
    "on_hand": 3,
    "reorder_point": 5,
    "reorder_recommended": true,
    "location": "DEMO-BASE-B"
  }
}
```

## Configuration

| Variable | Default | Purpose |
|---|---:|---|
| `LOGISTICS_WS_TOKEN` | empty | Optional demo token; empty means no token gate |
| `EVENT_INTERVAL_SECONDS` | `3` | Delay between generated events |
| `MAX_CLIENTS` | `100` | Maximum concurrent WebSocket clients |

## Design notes / next steps

- **Synthetic data only:** demo IDs are deliberately labeled `DEMO-*`.
- **Delivery semantics:** the sample broadcasts transient events; disconnected clients do not receive replay. Use a durable broker and consumer offsets if replay, ordering, or guaranteed delivery is required.
- **Scaling:** in-memory connections and broadcasts work for a single container. Multiple replicas require a shared broker/pub-sub layer.
- **Authorization:** the demo has no per-user or per-topic authorization. Enforce identity, role/attribute-based policy, and audit decisions in a real deployment.
- **Transport security:** local `ws://` is for development only. Use `wss://` through an approved TLS endpoint in deployed environments.
- **Observability:** add structured logs, metrics (connections, messages, errors, latency), tracing, and alerting before operational use.
- **Data governance:** apply approved classification markings, minimization, retention, and cross-domain/boundary controls appropriate to the actual environment.

## Troubleshooting

- Port `8000` already in use: change the host mapping to `"8001:8000"` and connect to port 8001.
- View logs: `docker compose logs -f logistics-ws`.
- Rebuild after changes: `docker compose up --build -d`.
