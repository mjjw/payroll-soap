from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_snapshot_is_synthetic():
    response = client.get("/api/logistics/snapshot")
    assert response.status_code == 200
    assert "SYNTHETIC" in response.json()["classification"]
