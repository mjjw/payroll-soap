INSERT OR IGNORE INTO employees (employee_id, first_name, last_name, email, department, job_title, annual_salary, hire_date) VALUES
('EMP001', 'Alice',  'Nguyen',    'alice.nguyen@example.com',   'Engineering',      'Senior Software Engineer', 128000.00, '2019-03-11'),
('EMP002', 'Marcus', 'Obi',       'marcus.obi@example.com',     'Finance',          'Payroll Analyst',          82000.00,  '2021-07-01'),
('EMP003', 'Priya',  'Shah',      'priya.shah@example.com',     'Human Resources',  'HR Business Partner',      95000.00,  '2018-11-20'),
('EMP004', 'Diego',  'Fernandez', 'diego.fernandez@example.com','Engineering',      'Engineering Manager',      152000.00, '2016-02-15'),
('EMP005', 'Hannah', 'Cole',      'hannah.cole@example.com',    'Sales',            'Account Executive',        88000.00,  '2022-05-09');

INSERT OR IGNORE INTO payslips (payslip_id, employee_id, period_start, period_end, gross_pay, tax_deduction, net_pay, issue_date) VALUES
('PS-0001', 'EMP001', '2026-07-01', '2026-07-15', 5333.33, 1173.33, 4160.00, '2026-07-16'),
('PS-0002', 'EMP001', '2026-07-16', '2026-07-31', 5333.33, 1173.33, 4160.00, '2026-08-01'),
('PS-0003', 'EMP002', '2026-07-01', '2026-07-15', 3416.67, 751.67,  2665.00, '2026-07-16'),
('PS-0004', 'EMP003', '2026-07-01', '2026-07-15', 3958.33, 870.83,  3087.50, '2026-07-16');
