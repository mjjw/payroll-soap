# Payroll SOAP API

A contract-first SOAP web service (Spring-WS on Spring Boot 3 / Java 21) over a mock payroll
database (SQLite), fully containerized with Docker Compose.

## Stack

- Java 21, Spring Boot 3.3
- Spring-WS (contract-first, XSD in `src/main/resources/xsd/payroll.xsd`)
- JAXB classes generated from the XSD at build time (`jaxb2-maven-plugin`)
- Spring Data JPA + SQLite (embedded, file-based — via `sqlite-jdbc` and Hibernate's
  community `SQLiteDialect`)
- Seeded mock data (`src/main/resources/data.sql`) — 5 employees, a handful of payslips
- Docker Compose: a single `app` service, exposed on port 9035; the SQLite file is bind-mounted
  to `./data/payroll.db` on the host (handy for opening directly in DBeaver or similar)

## Project layout

```
payroll-soap/
├── pom.xml
├── Dockerfile
├── docker-compose.yml
└── src/main/
    ├── resources/
    │   ├── xsd/payroll.xsd        # SOAP contract (source of truth)
    │   ├── application.yml
    │   └── data.sql               # mock data seed
    └── java/com/example/payroll/
        ├── PayrollApplication.java
        ├── config/WebServiceConfig.java   # WSDL + dispatcher servlet
        ├── domain/                        # JPA entities
        ├── repository/                    # Spring Data repos
        ├── service/                       # business logic + SOAP fault
        └── endpoint/PayrollEndpoint.java  # maps SOAP ops -> service
```

(`com.example.payroll.ws.*` — the JAXB request/response/type classes — is generated into
`target/generated-sources/jaxb` at build time; it isn't checked in.)

## Run it

```bash
docker compose up --build
```

This builds the app image and starts it. On first boot the SQLite database file is created
at `./data/payroll.db` (on the host, via the bind mount) and seeded with mock data.
The service listens on `http://localhost:9035`.

- WSDL: http://localhost:9035/ws/payroll.wsdl
- Endpoint: http://localhost:9035/ws

To build/run locally without Docker, no external database is needed — SQLite is embedded.
By default it writes `./payroll.db` in the working directory (override with `DB_PATH`):

```bash
mvn spring-boot:run
```

## Operations

| Operation             | Input                                   | Output              |
|-----------------------|------------------------------------------|----------------------|
| `getEmployee`         | `employeeId`                            | `employee`           |
| `listEmployees`       | —                                        | `employee[]`         |
| `getPayslips`         | `employeeId`                            | `payslip[]`          |
| `runPayroll`          | `employeeId`, `periodStart`, `periodEnd`| `payslip` (computed) |

Unknown employee IDs return a SOAP `Fault` (client fault) instead of a normal response.

`runPayroll` computes a mock payslip: annual salary ÷ 24 semi-monthly periods, minus a flat
22% tax rate — good enough for demo/testing purposes, not real payroll math.

## Sample requests

### Get one employee

```bash
curl -s -X POST http://localhost:9035/ws \
  -H 'Content-Type: text/xml;charset=UTF-8' \
  -H 'SOAPAction: ""' \
  -d '<?xml version="1.0"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="http://example.com/payroll">
  <soapenv:Body>
    <pay:getEmployeeRequest>
      <pay:employeeId>EMP001</pay:employeeId>
    </pay:getEmployeeRequest>
  </soapenv:Body>
</soapenv:Envelope>'
```

### List all employees

```bash
curl -s -X POST http://localhost:9035/ws \
  -H 'Content-Type: text/xml;charset=UTF-8' \
  -H 'SOAPAction: ""' \
  -d '<?xml version="1.0"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="http://example.com/payroll">
  <soapenv:Body>
    <pay:listEmployeesRequest/>
  </soapenv:Body>
</soapenv:Envelope>'
```

### Get payslips for an employee

```bash
curl -s -X POST http://localhost:9035/ws \
  -H 'Content-Type: text/xml;charset=UTF-8' \
  -H 'SOAPAction: ""' \
  -d '<?xml version="1.0"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="http://example.com/payroll">
  <soapenv:Body>
    <pay:getPayslipsRequest>
      <pay:employeeId>EMP001</pay:employeeId>
    </pay:getPayslipsRequest>
  </soapenv:Body>
</soapenv:Envelope>'
```

### Run payroll (compute + persist a new payslip)

```bash
curl -s -X POST http://localhost:9035/ws \
  -H 'Content-Type: text/xml;charset=UTF-8' \
  -H 'SOAPAction: ""' \
  -d '<?xml version="1.0"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pay="http://example.com/payroll">
  <soapenv:Body>
    <pay:runPayrollRequest>
      <pay:employeeId>EMP002</pay:employeeId>
      <pay:periodStart>2026-08-01</pay:periodStart>
      <pay:periodEnd>2026-08-15</pay:periodEnd>
    </pay:runPayrollRequest>
  </soapenv:Body>
</soapenv:Envelope>'
```

You can also point SoapUI or Postman's SOAP tooling at the WSDL URL above and it will
generate sample requests for all four operations automatically.

## Extending

- Add a `deleteEmployee` / `createEmployee` operation by adding elements to `payroll.xsd`
  and a matching `@PayloadRoot` method in `PayrollEndpoint`.
- The current fault handling returns a generic SOAP `Fault` element for unknown employees.
  For a richer fault with structured detail (e.g. an `employeeId` field in the fault),
  add a `SoapFaultMappingExceptionResolver`/custom `SoapFaultDefinitionExceptionResolver`
  bean and a `<xs:element name="employeeNotFoundFault">` detail type in the XSD.
- Swap the flat-tax mock calculation in `PayrollService.runPayroll` for real tax tables.
- SQLite only allows one writer at a time (the connection pool is capped at 1 for this
  reason). Fine for a mock/demo API; swap the JDBC URL, driver, and Hibernate dialect back
  to a client-server database (Postgres, MariaDB, etc.) if you need concurrent writes.
