import asyncio
import json
import logging
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal, Optional

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field

from .dds_bus import RULES, SCENARIOS, DDSBus, EngineTelemetry

logging.basicConfig(level=logging.INFO)
bus = DDSBus()


@asynccontextmanager
async def lifespan(app: FastAPI):
    bus.start(asyncio.get_running_loop())
    yield
    bus.stop()


app = FastAPI(title="Aircraft Maintenance Diagnostics - DDS Service",
              version="1.0.0", lifespan=lifespan)


# ------------------------------------------------------------------ models
class FaultIn(BaseModel):
    tail_number: str = Field(examples=["N101AC"])
    ata_chapter: str = Field(examples=["29"])
    code: str = Field(examples=["29-10-05"])
    system: str = Field(examples=["Hydraulics"])
    severity: Literal["MINOR", "MAJOR", "CRITICAL"]
    description: str


class TelemetryIn(BaseModel):
    tail_number: str
    engine_id: int = Field(ge=1, le=4)
    egt_c: float = 850
    n1_pct: float = 85
    n2_pct: float = 92
    oil_pressure_psi: float = 55
    oil_temp_c: float = 105
    vibration_ips: float = 0.3
    fuel_flow_kgh: float = 1100


class InjectIn(BaseModel):
    source_id: str = Field(examples=["N101AC-E1"])
    scenario: Optional[Literal["oil_leak", "egt_overtemp", "bearing_wear"]] = Field(
        None, description="null clears the scenario")


# ------------------------------------------------------------------ routes
@app.get("/", include_in_schema=False)
def dashboard():
    return FileResponse(Path(__file__).parent / "static" / "index.html")


@app.get("/health")
def health():
    return {"status": "ok" if bus.running else "starting", "dds_domain": bus.domain,
            "simulator": bus.sim_enabled, "time": time.time()}


@app.get("/api/fleet")
def fleet():
    return {"engines": sorted(bus.snapshot(), key=lambda r: r["source_id"]),
            "thresholds": {k: v[:3] for k, v in RULES.items()}}


@app.get("/api/telemetry")
def telemetry(tail: Optional[str] = None, limit: int = Query(100, ge=1, le=1000)):
    return bus.recent("telemetry", limit, tail)


@app.get("/api/faults")
def faults(tail: Optional[str] = None, limit: int = Query(50, ge=1, le=300)):
    return bus.recent("faults", limit, tail)


@app.get("/api/alerts")
def alerts(tail: Optional[str] = None, limit: int = Query(50, ge=1, le=300)):
    return bus.recent("alerts", limit, tail)


@app.post("/api/faults", status_code=202)
def post_fault(f: FaultIn):
    fid = bus.new_fault(f.tail_number, f.ata_chapter, f.code, f.system,
                        f.severity, f.description)
    return {"published": "Maint_FaultReport", "fault_id": fid}


@app.post("/api/telemetry", status_code=202)
def post_telemetry(t: TelemetryIn):
    bus.publish("telemetry", EngineTelemetry(
        source_id=f"{t.tail_number}-E{t.engine_id}", tail_number=t.tail_number,
        engine_id=t.engine_id, timestamp=time.time(), egt_c=t.egt_c, n1_pct=t.n1_pct,
        n2_pct=t.n2_pct, oil_pressure_psi=t.oil_pressure_psi, oil_temp_c=t.oil_temp_c,
        vibration_ips=t.vibration_ips, fuel_flow_kgh=t.fuel_flow_kgh))
    return {"published": "Maint_EngineTelemetry"}


@app.post("/api/simulator/inject")
def inject(req: InjectIn):
    if not bus.sim_enabled:
        raise HTTPException(409, "Simulator disabled (SIM_ENABLED=0)")
    if req.source_id not in bus.engines:
        raise HTTPException(404, f"Unknown source_id; valid: {sorted(bus.engines)}")
    bus.inject(req.source_id, req.scenario)
    return {"source_id": req.source_id, "scenario": req.scenario}


@app.get("/api/stats")
def stats():
    return {"domain": bus.domain, "topics": bus.stats, "scenarios": SCENARIOS,
            "engines": sorted(bus.engines)}


@app.get("/api/stream")
async def stream(request: Request):
    """Server-Sent Events: every DDS sample received, as {topic, data}."""
    q = bus.subscribe()

    async def gen():
        try:
            yield "retry: 2000\n\n"
            while not await request.is_disconnected():
                try:
                    evt = await asyncio.wait_for(q.get(), 15)
                    yield f"data: {json.dumps(evt)}\n\n"
                except asyncio.TimeoutError:
                    yield ": ping\n\n"
        finally:
            bus.unsubscribe(q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
