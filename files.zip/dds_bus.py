"""Eclipse Cyclone DDS bus for mock aircraft maintenance diagnostics.

Topics (all in one DDS domain):
  Maint_EngineTelemetry  - engine sensor samples      (key: source_id)
  Maint_FaultReport      - ATA-coded fault reports    (key: fault_id)
  Maint_MaintenanceAlert - analyzer-derived alerts    (key: alert_id)

A simulator publishes telemetry/faults, an analyzer subscribes to both and
publishes alerts, and the web layer subscribes to everything.
"""
import asyncio
import dataclasses
import logging
import os
import random
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass

from cyclonedds.domain import DomainParticipant
from cyclonedds.idl import IdlStruct
from cyclonedds.idl.annotations import key
from cyclonedds.pub import DataWriter
from cyclonedds.qos import Policy, Qos
from cyclonedds.sub import DataReader
from cyclonedds.topic import Topic
from cyclonedds.util import duration

log = logging.getLogger("dds_bus")


# ---------------------------------------------------------------- IDL types
@dataclass
class EngineTelemetry(IdlStruct, typename="Maint.EngineTelemetry"):
    source_id: str
    key("source_id")
    tail_number: str
    engine_id: int
    timestamp: float
    egt_c: float
    n1_pct: float
    n2_pct: float
    oil_pressure_psi: float
    oil_temp_c: float
    vibration_ips: float
    fuel_flow_kgh: float


@dataclass
class FaultReport(IdlStruct, typename="Maint.FaultReport"):
    fault_id: str
    key("fault_id")
    tail_number: str
    ata_chapter: str
    code: str
    system: str
    severity: str  # MINOR | MAJOR | CRITICAL
    description: str
    timestamp: float


@dataclass
class MaintenanceAlert(IdlStruct, typename="Maint.MaintenanceAlert"):
    alert_id: str
    key("alert_id")
    tail_number: str
    source_id: str
    severity: str  # ADVISORY | WARNING | CRITICAL
    parameter: str
    message: str
    recommended_action: str
    timestamp: float


TOPICS = {
    "telemetry": ("Maint_EngineTelemetry", EngineTelemetry),
    "faults": ("Maint_FaultReport", FaultReport),
    "alerts": ("Maint_MaintenanceAlert", MaintenanceAlert),
}

# param: (kind, warn, crit, label, unit, recommended action)
RULES = {
    "egt_c": ("high", 950, 1000, "EGT", "C", "Borescope HPT section; review EGT margin trend (ATA 77-21)"),
    "oil_pressure_psi": ("low", 30, 20, "Oil pressure", "psi", "Inspect oil system for leaks; check scavenge filter (ATA 79-20)"),
    "oil_temp_c": ("high", 150, 170, "Oil temperature", "C", "Check oil cooler and FCOC operation (ATA 79-21)"),
    "vibration_ips": ("high", 0.8, 1.2, "Vibration", "ips", "Trim balance check / inspect bearings (ATA 77-31)"),
}

FAULT_CATALOG = [
    ("36", "36-11-02", "Pneumatic", "MINOR", "Bleed air duct pressure fluctuation"),
    ("29", "29-10-05", "Hydraulics", "MAJOR", "Hydraulic system B low quantity"),
    ("32", "32-41-01", "Landing Gear", "MINOR", "Main gear brake temp sensor intermittent"),
    ("73", "73-21-04", "Engine Fuel", "MAJOR", "Fuel metering unit position mismatch"),
    ("24", "24-21-03", "Electrical", "MINOR", "Generator 2 voltage regulator drift"),
    ("34", "34-12-07", "Navigation", "MINOR", "ADIRU 2 attitude disagree"),
    ("26", "26-12-01", "Fire Protection", "CRITICAL", "Engine 1 fire loop B fault"),
]

SCENARIOS = ("oil_leak", "egt_overtemp", "bearing_wear")
FLEET = ["N101AC", "N202AC", "N303AC"]


def evaluate(param: str, value: float):
    kind, warn, crit, *_ = RULES[param]
    if kind == "high":
        return "CRITICAL" if value >= crit else "WARNING" if value >= warn else None
    return "CRITICAL" if value <= crit else "WARNING" if value <= warn else None


# ---------------------------------------------------------------- the bus
class DDSBus:
    def __init__(self):
        self.domain = int(os.getenv("DDS_DOMAIN_ID", "0"))
        self.sim_enabled = os.getenv("SIM_ENABLED", "1") == "1"
        self.sim_hz = max(0.1, float(os.getenv("SIM_RATE_HZ", "1")))
        self.running = False
        self.loop = None
        self.subs = set()
        self.lock = threading.Lock()
        self.latest = {}
        self.history = {
            "telemetry": deque(maxlen=3000),
            "faults": deque(maxlen=300),
            "alerts": deque(maxlen=300),
        }
        self.stats = {k: {"written": 0, "received": 0} for k in TOPICS}
        self._last_alert = {}
        self._threads = []
        self.engines = {
            f"{t}-E{e}": {"tail": t, "eng": e, "scenario": None, "p": 0.0,
                          "bias": random.uniform(-15, 15)}
            for t in FLEET for e in (1, 2)
        }

    # ---- lifecycle
    def start(self, loop):
        self.loop = loop
        self.running = True
        self.dp = DomainParticipant(self.domain)
        qos = Qos(
            Policy.Reliability.Reliable(duration(seconds=1)),
            Policy.History.KeepLast(50),
        )
        self.writers, self.readers = {}, {}
        for kind, (name, cls) in TOPICS.items():
            topic = Topic(self.dp, name, cls, qos=qos)
            self.writers[kind] = DataWriter(self.dp, topic, qos=qos)
            self.readers[kind] = DataReader(self.dp, topic, qos=qos)
        for kind, (_, cls) in TOPICS.items():
            self._spawn(self._pump, kind, cls)
        if self.sim_enabled:
            self._spawn(self._simulate)
        log.info("DDS bus up on domain %s (simulator=%s)", self.domain, self.sim_enabled)

    def stop(self):
        self.running = False
        for t in self._threads:
            t.join(timeout=2)

    def _spawn(self, fn, *args):
        t = threading.Thread(target=fn, args=args, daemon=True, name=fn.__name__)
        t.start()
        self._threads.append(t)

    # ---- pub / sub
    def publish(self, kind, sample):
        self.writers[kind].write(sample)
        self.stats[kind]["written"] += 1

    def _pump(self, kind, cls):
        reader = self.readers[kind]
        while self.running:
            try:
                for s in reader.take(N=64):
                    if isinstance(s, cls):
                        self._on_sample(kind, s)
            except Exception:
                log.exception("reader %s failed", kind)
            time.sleep(0.05)

    def _on_sample(self, kind, sample):
        d = dataclasses.asdict(sample)
        d["received_at"] = time.time()
        with self.lock:
            self.history[kind].append(d)
            self.stats[kind]["received"] += 1
            if kind == "telemetry":
                self.latest[d["source_id"]] = d
        self._emit({"topic": kind, "data": d})
        if kind == "telemetry":
            self._analyze_telemetry(sample)
        elif kind == "faults":
            self._analyze_fault(sample)

    # ---- SSE fan-out
    def subscribe(self):
        q = asyncio.Queue(maxsize=500)
        self.subs.add(q)
        return q

    def unsubscribe(self, q):
        self.subs.discard(q)

    def _emit(self, evt):
        if self.loop and self.loop.is_running():
            self.loop.call_soon_threadsafe(self._fanout, evt)

    def _fanout(self, evt):
        for q in list(self.subs):
            try:
                q.put_nowait(evt)
            except asyncio.QueueFull:
                pass

    # ---- analyzer (DDS subscriber -> DDS publisher)
    def _raise_alert(self, tail, source, severity, param, message, action):
        k = (source, param, severity)
        now = time.time()
        if now - self._last_alert.get(k, 0) < 30:
            return
        self._last_alert[k] = now
        self.publish("alerts", MaintenanceAlert(
            alert_id=uuid.uuid4().hex[:8], tail_number=tail, source_id=source,
            severity=severity, parameter=param, message=message,
            recommended_action=action, timestamp=now))

    def _analyze_telemetry(self, t: EngineTelemetry):
        for param, (_, _, _, label, unit, action) in RULES.items():
            v = getattr(t, param)
            sev = evaluate(param, v)
            if sev:
                self._raise_alert(t.tail_number, t.source_id, sev, param,
                                  f"{label} {v:.2f} {unit} on engine {t.engine_id}", action)

    def _analyze_fault(self, f: FaultReport):
        if f.severity in ("MAJOR", "CRITICAL"):
            sev = "CRITICAL" if f.severity == "CRITICAL" else "WARNING"
            self._raise_alert(f.tail_number, f.tail_number, sev, f"fault:{f.code}",
                              f"{f.system}: {f.description}",
                              f"Troubleshoot per AMM ATA {f.ata_chapter}; assess MEL dispatch relief")

    # ---- simulator
    def inject(self, source_id, scenario):
        st = self.engines[source_id]
        st["scenario"], st["p"] = scenario, 0.0

    def new_fault(self, tail, ata, code, system, severity, description):
        f = FaultReport(uuid.uuid4().hex[:8], tail, ata, code, system, severity,
                        description, time.time())
        self.publish("faults", f)
        return f.fault_id

    def _simulate(self):
        n = 0
        while self.running:
            t0 = time.time()
            for sid, st in self.engines.items():
                if st["scenario"]:
                    st["p"] = min(1.6, st["p"] + 0.03)
                p, sc = st["p"], st["scenario"]
                egt = 850 + st["bias"] + random.gauss(0, 4)
                oilp = 55 + random.gauss(0, 0.8)
                oilt = 105 + random.gauss(0, 1.5)
                vib = 0.3 + abs(random.gauss(0, 0.03))
                if sc == "oil_leak":
                    oilp -= 35 * p
                    oilt += 40 * p
                elif sc == "egt_overtemp":
                    egt += 150 * p
                elif sc == "bearing_wear":
                    vib += 0.9 * p
                    oilt += 15 * p
                self.publish("telemetry", EngineTelemetry(
                    source_id=sid, tail_number=st["tail"], engine_id=st["eng"],
                    timestamp=time.time(), egt_c=round(egt, 1),
                    n1_pct=round(85 + random.gauss(0, 0.3), 1),
                    n2_pct=round(92 + random.gauss(0, 0.2), 1),
                    oil_pressure_psi=round(oilp, 1), oil_temp_c=round(oilt, 1),
                    vibration_ips=round(vib, 2),
                    fuel_flow_kgh=round(1100 + random.gauss(0, 12) + (egt - 850) * 2, 0)))
            n += 1
            if random.random() < 0.025:
                a, c, s, sev, d = random.choice(FAULT_CATALOG)
                self.new_fault(random.choice(FLEET), a, c, s, sev, d)
            time.sleep(max(0.0, 1.0 / self.sim_hz - (time.time() - t0)))

    # ---- queries
    def snapshot(self):
        with self.lock:
            return list(self.latest.values())

    def recent(self, kind, limit=100, tail=None):
        with self.lock:
            rows = [r for r in reversed(self.history[kind])
                    if not tail or r["tail_number"] == tail]
        return rows[:limit]
