package com.example.payroll.domain;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.time.LocalDate;

/**
 * The xerial sqlite-jdbc driver stores/parses DATE columns using its own internal
 * date-string format (default "yyyy-MM-dd HH:mm:ss.SSS"). When a plain ISO date like
 * "2026-07-01" ends up in that column (which is exactly what Hibernate + our data.sql
 * seed write), the driver's own read-back parsing throws "unparseable date".
 * <p>
 * Storing dates as plain TEXT via this converter — instead of letting Hibernate bind them
 * as java.sql.Date — sidesteps the driver's date parsing entirely and stores/reads a
 * simple "yyyy-MM-dd" string.
 */
@Converter(autoApply = false)
public class LocalDateAttributeConverter implements AttributeConverter<LocalDate, String> {

    @Override
    public String convertToDatabaseColumn(LocalDate attribute) {
        return attribute == null ? null : attribute.toString(); // ISO-8601: yyyy-MM-dd
    }

    @Override
    public LocalDate convertToEntityAttribute(String dbData) {
        return dbData == null ? null : LocalDate.parse(dbData);
    }
}
